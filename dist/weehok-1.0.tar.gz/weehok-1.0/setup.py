from setuptools import setup

setup(
    name='weehok',
    version='1.0',
    description='It just makes ur life easy so why not use it?',
    author='0xleft',
    url='https://pageup.lt/',
    packages=['weehok'],
    long_description="Amazing",
    license='Apache License 2.0',
)